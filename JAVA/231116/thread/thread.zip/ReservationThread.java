package edu.java.thread;

public class ReservationThread extends Thread {
	
	
	

}
